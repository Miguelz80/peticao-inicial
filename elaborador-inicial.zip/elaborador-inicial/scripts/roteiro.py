"""Roteiro — liga o texto jurídico de cada tese aos blocos do Gerador.

Lê `references/teses.md`, escolhe os blocos que se aplicam ao caso, preenche os campos
e devolve uma `Peca` pronta para `gerar_peticao.montar()`.

Três travas, todas por motivo prático:

1. **Campo sem valor interrompe a geração.** Peça com `{restituicao}` literal, ou com
   um branco no lugar do valor, é pior do que peça nenhuma — passa despercebida na
   leitura rápida e vai a protocolo.
2. **Bloco sem texto do escritório vira marcador visível e bloqueia a entrega.** Nunca
   redigir fundamentação jurídica de improviso para tapar buraco de modelo faltando.
3. **Bloco condicional cujo fato é desconhecido não some em silêncio** — volta como
   pergunta. Um capítulo que deveria existir e não existe é invisível na revisão.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field

from gerar_peticao import (
    Peca, Titulo, Paragrafo, Citacao, Espaco, tabela_de_reajuste, caixa_de_resumo,
)

CATALOGO = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "references", "teses.md")

MARCA_PENDENTE = "⟦PENDENTE"


class CampoAusente(Exception):
    pass


# Cada campo com o que é e onde achar. Quem lê a mensagem é a colega do processual,
# não quem escreveu o código: lista de nome de variável não é pergunta.
CAMPOS = {
    "plano": ("nome do plano de saúde", "carteira do plano ou contrato"),
    "inicio_contrato": ("data de início do contrato",
                        "contrato, proposta de adesão ou carteira"),
    "comarca": ("comarca onde a ação será distribuída",
                "domicílio da parte autora, no comprovante de residência"),
    "juizo": ("juízo a que a peça é endereçada, ex.: “Vara Cível” ou “Juizado "
              "Especial Cível do Consumidor”",
              "decisão da advogada — depende do valor da causa e da comarca; o "
              "Juizado tem teto de 40 salários mínimos"),
    "qualificacao_autor": ("qualificação completa da parte autora, como vai na peça",
                           "documento pessoal, contrato social e comprovante de "
                           "residência"),
    "qualificacao_re": ("qualificação completa da parte ré, como vai na peça",
                        "carteirinha, contrato ou boleto — razão social, CNPJ e "
                        "endereço saem do documento do caso, nunca de cadastro"),
    "advogados": ("advogados que assinam, um por linha, no formato “Nome | OAB/UF "
                  "00.000”", "procuração"),
    "data_peca": ("local e data da peça, ex.: “Salvador/BA, 23 de setembro de 2026”",
                  "data em que a peça será protocolada"),
    "idade": ("idade da parte autora, em anos", "documento pessoal"),
    "competencia_atual": ("mês e ano da mensalidade mais recente",
                          "última competência da planilha, ex.: julho de 2026"),
    "maior_reajuste": ("maior percentual de reajuste aplicado",
                       "coluna de reajuste aplicado da planilha"),
    "valor_da_causa": ("valor da causa",
                       "decisão da advogada — a fórmula do escritório ainda não está "
                       "fechada (pergunta A6)"),
    "narrativa_hipossuficiencia": (
        "parágrafo sobre a situação econômica da parte autora",
        "extratos, IRPF e comprovantes de despesa — é fato do caso, não texto de "
        "modelo"),
    "processo_anterior": ("número do processo anterior, que foi desistido",
                          "comprovante de distribuição da ação anterior"),
    "comarca_anterior": ("comarca onde a ação anterior foi distribuída",
                         "autos da ação anterior"),
}

# Estes não se pedem a ninguém: saem do Calculador. Se faltam, o cálculo não rodou.
DO_CALCULO = {
    "valor_pago_atual": "mensalidade atual",
    "valor_devido_atual": "mensalidade devida",
    "diferenca_mensal": "diferença mensal",
    "restituicao": "restituição dos últimos 3 anos",
    # A peça real pede a restituição em dobro e escreve o valor dobrado por extenso,
    # no capítulo e no pedido. Deixar quem opera dobrar à mão é convidar divergência
    # entre os dois — e a Conferência reprovaria, com razão.
    "restituicao_dobro": "restituição em dobro",
}


class TeseSemCatalogo(Exception):
    pass


# --------------------------------------------------------------------------- #
# Leitura do catálogo
# --------------------------------------------------------------------------- #

@dataclass
class BlocoTese:
    numeral: str
    titulo: str
    condicao: str = "sempre"
    fundamentos: str = ""
    pendente: str = ""
    revisar: str = ""
    tabela: str = ""
    tipo: str = ""              # "" = capítulo comum | "pedidos" = lista por letras
    paragrafos: list[str] = field(default_factory=list)


@dataclass
class Tese:
    nome: str
    pendente: str = ""
    revisar: str = ""
    blocos: list[BlocoTese] = field(default_factory=list)


RE_TESE = re.compile(r"^## TESE:\s*(\S+)\s*$")
RE_BLOCO = re.compile(r"^### BLOCO:\s*([^|]+?)\s*\|\s*(.+?)\s*$")
RE_DIRETIVA = re.compile(r"^@(\w+):\s*(.*)$")


def carregar(caminho: str = CATALOGO) -> dict[str, Tese]:
    with open(caminho, encoding="utf-8") as fh:
        linhas = fh.read().split("\n")

    teses: dict[str, Tese] = {}
    tese = bloco = None
    dentro_do_formato = False
    buffer: list[str] = []

    def fechar_paragrafo():
        if bloco is not None and buffer:
            bloco.paragrafos.append(" ".join(buffer).strip())
        buffer.clear()

    for linha in linhas:
        if linha.startswith("```"):
            dentro_do_formato = not dentro_do_formato
            continue
        if dentro_do_formato:
            continue

        m = RE_TESE.match(linha)
        if m:
            fechar_paragrafo()
            tese = Tese(nome=m.group(1))
            teses[tese.nome] = tese
            bloco = None
            continue

        m = RE_BLOCO.match(linha)
        if m and tese is not None:
            fechar_paragrafo()
            bloco = BlocoTese(numeral=m.group(1), titulo=m.group(2))
            tese.blocos.append(bloco)
            continue

        m = RE_DIRETIVA.match(linha)
        if m and tese is not None:
            fechar_paragrafo()
            chave, valor = m.group(1), m.group(2).strip()
            alvo = bloco if bloco is not None else tese
            if hasattr(alvo, chave):
                setattr(alvo, chave, valor)
            continue

        if bloco is None:
            continue
        # separadores e outros títulos do arquivo não são texto da peça
        if linha.strip().startswith(("---", "#")):
            fechar_paragrafo()
            continue
        if linha.strip().startswith("- "):
            fechar_paragrafo()
            bloco.paragrafos.append(linha.strip())
        elif linha.strip():
            buffer.append(linha.strip())
        else:
            fechar_paragrafo()

    fechar_paragrafo()
    return teses


# --------------------------------------------------------------------------- #
# Condições
# --------------------------------------------------------------------------- #

RE_CONDICAO = re.compile(r"^(\w+)\s*(==|!=|>=|<=)\s*(.+)$")


def avaliar(condicao: str, fatos: dict[str, str]) -> bool | None:
    """True aplica, False não aplica, None = o fato é desconhecido (vira pergunta)."""
    condicao = (condicao or "sempre").strip()
    if condicao in ("", "sempre"):
        return True
    m = RE_CONDICAO.match(condicao)
    if not m:
        return None
    fato, operador, esperado = m.group(1), m.group(2), m.group(3).strip()
    if fato not in fatos or fatos[fato] in (None, "", "DESCONHECIDO"):
        return None
    valor = str(fatos[fato])
    if operador in (">=", "<="):
        try:
            a, b = float(valor.replace(",", ".")), float(esperado.replace(",", "."))
        except ValueError:
            return None
        return a >= b if operador == ">=" else a <= b
    return (valor == esperado) if operador == "==" else (valor != esperado)


# --------------------------------------------------------------------------- #
# Preenchimento
# --------------------------------------------------------------------------- #

RE_ITEM = re.compile(r"^-\s*\[([^\]]+)\]\s*(.+)$")
LETRAS = "abcdefghijklmnopqrstuvwxyz"


ROMANOS = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"),
           (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]


def romano(n: int) -> str:
    saida = []
    for valor, simbolo in ROMANOS:
        while n >= valor:
            saida.append(simbolo)
            n -= valor
    return "".join(saida)


RE_CAMPO = re.compile(r"\{(\w+)\}")


def preencher(texto: str, dados: dict[str, str]) -> tuple[str, set[str]]:
    faltando = {c for c in RE_CAMPO.findall(texto)
                if c not in dados or dados[c] in (None, "")}
    if faltando:
        return texto, faltando
    return RE_CAMPO.sub(lambda m: str(dados[m.group(1)]), texto), set()


# --------------------------------------------------------------------------- #
# Montagem
# --------------------------------------------------------------------------- #

@dataclass
class Roteiro:
    peca: Peca
    pendencias: list[str] = field(default_factory=list)
    perguntas: list[str] = field(default_factory=list)
    revisoes: list[str] = field(default_factory=list)

    @property
    def pronto(self) -> bool:
        return not self.pendencias and not self.perguntas

    @property
    def precisa_revisao(self) -> bool:
        """Texto redigido a partir dos fundamentos documentados, não extraído de peça
        real do escritório. Gera peça completa, mas exige leitura da advogada antes do
        primeiro protocolo — e o aviso tem que aparecer no Espelho."""
        return bool(self.revisoes)


def _abertura_ou_fecho(r: "Roteiro", bloco, dados: dict[str, str]) -> set[str]:
    """Renderiza o cabeçalho e o rodapé da peça.

    Linha começando com "!" vira endereçamento (negrito, sem recuo); "=" vira
    assinatura centralizada, no formato "Nome | OAB"; o resto é parágrafo corrido sem
    recuo, que é como a qualificação das partes aparece na peça do escritório.
    """
    from gerar_peticao import Enderecamento, Assinatura, Espaco

    faltando_geral: set[str] = set()
    for paragrafo in bloco.paragrafos:
        marca, corpo = "", paragrafo
        if paragrafo[:1] in ("!", "="):
            marca, corpo = paragrafo[0], paragrafo[1:].lstrip()
        texto, faltando = preencher(corpo, dados)
        faltando_geral |= faltando
        if marca == "!":
            r.peca.add(Enderecamento(texto))
        elif marca == "=":
            nome, _, oab = texto.partition("|")
            r.peca.add(Espaco(), Assinatura(nome.strip(), oab.strip()))
        else:
            r.peca.add(Paragrafo(texto, recuo=False))
    return faltando_geral


def titulos_do_catalogo(tese_nome: str, catalogo: str = CATALOGO) -> list[str]:
    """Todos os títulos de capítulo previstos para a tese, aplicáveis ou não.

    É a lista contra a qual a Conferência mede o documento: capítulo fora dela é
    improviso ou veio de outra tese.
    """
    teses = carregar(catalogo)
    if tese_nome not in teses:
        return []
    return [b.titulo for b in teses[tese_nome].blocos]


def montar_peca(tese_nome: str, fatos: dict[str, str], dados: dict[str, str],
                resultado_calculo=None, catalogo: str = CATALOGO) -> Roteiro:
    teses = carregar(catalogo)
    if tese_nome not in teses:
        raise TeseSemCatalogo(
            f"tese “{tese_nome}” não está em {os.path.basename(catalogo)} — "
            f"disponíveis: {', '.join(sorted(teses))}")

    tese = teses[tese_nome]
    r = Roteiro(peca=Peca())
    if tese.pendente:
        r.pendencias.append(f"{tese_nome}: {tese.pendente}")
    if tese.revisar:
        r.revisoes.append(f"{tese_nome}: {tese.revisar}")

    faltando_geral: set[str] = set()
    numero = 0

    for bloco in tese.blocos:
        aplica = avaliar(bloco.condicao, fatos)
        if aplica is False:
            continue
        if aplica is None:
            r.perguntas.append(
                f"O capítulo “{bloco.titulo}” depende de “{bloco.condicao}”, e esse "
                f"dado não está definido. Ele entra na peça ou não?")
            continue

        # Abertura (endereçamento, qualificação das partes, nome da ação) e fecho
        # (local, data e assinaturas) NÃO são capítulos: não recebem numeral romano nem
        # título. Sem eles a peça começava em "I. DOS FATOS" — sem juízo, sem partes,
        # sem nome de ação e sem assinatura. Saiu assim em todas as peças geradas até
        # aqui, porque eu conferia capítulos, valores e editabilidade, nunca se o
        # documento abria como petição.
        if bloco.tipo in ("abertura", "fecho"):
            faltando_geral |= _abertura_ou_fecho(r, bloco, dados)
            continue

        numero += 1
        r.peca.add(Titulo(f"{romano(numero)}.", bloco.titulo))

        if bloco.revisar:
            r.revisoes.append(f"{tese_nome} · {bloco.titulo}: {bloco.revisar}")

        if bloco.pendente:
            r.pendencias.append(f"{tese_nome} · {bloco.titulo}: {bloco.pendente}")
            r.peca.add(Paragrafo(
                f"**{MARCA_PENDENTE}: texto não disponível.** Este capítulo precisa "
                f"sustentar: {bloco.fundamentos}⟧"))
            continue

        if bloco.tipo == "pedidos":
            faltando_geral |= _pedidos(r, bloco, fatos, dados)
        else:
            for paragrafo in bloco.paragrafos:
                # "> " marca ementa de julgado: sai recuada e em itálico, como no
                # padrão do escritório, não como parágrafo de argumentação.
                citacao = paragrafo.startswith("> ")
                texto, faltando = preencher(paragrafo[2:] if citacao else paragrafo,
                                            dados)
                faltando_geral |= faltando
                r.peca.add(Citacao(texto) if citacao else Paragrafo(texto))

        if bloco.tabela == "reajuste" and resultado_calculo is not None:
            r.peca.add(caixa_de_resumo(resultado_calculo),
                       tabela_de_reajuste(resultado_calculo))

    _conferir_coerencia(r)

    if faltando_geral:
        do_caso = sorted(faltando_geral - set(DO_CALCULO))
        do_calculo = sorted(faltando_geral & set(DO_CALCULO))
        linhas = []
        if do_caso:
            linhas.append("Para montar a peça ainda preciso destes dados:")
            for campo in do_caso:
                o_que, onde = CAMPOS.get(campo, (campo, "—"))
                linhas.append(f"  · {o_que}  (campo “{campo}”, em: {onde})")
        if do_calculo:
            linhas.append("Faltam valores que saem do cálculo — sinal de que o cálculo "
                          "não rodou ou parou antes do fim:")
            linhas += [f"  · {DO_CALCULO[c]}  (campo “{c}”)" for c in do_calculo]
        linhas.append("Não gero com campo em branco: no meio do texto passa "
                      "despercebido na revisão e vai a protocolo assim.")
        raise CampoAusente("\n".join(linhas))

    r.peca.add(Espaco())
    return r


def _pedidos(r: Roteiro, bloco: BlocoTese, fatos: dict[str, str],
             dados: dict[str, str]) -> set[str]:
    """Lista por letras, no padrão do escritório: a), b), c)...

    Cada item carrega a própria condição, pelos mesmos fatos dos capítulos — é o que
    impede a peça de pedir tutela num capítulo que não existe.
    """
    faltando: set[str] = set()
    itens: list[str] = []

    for linha in bloco.paragrafos:
        m = RE_ITEM.match(linha)
        if not m:
            texto, falta = preencher(linha, dados)
            faltando |= falta
            r.peca.add(Paragrafo(texto))
            continue
        condicao, texto = m.group(1), m.group(2)
        aplica = avaliar(condicao, fatos)
        if aplica is False:
            continue
        if aplica is None:
            r.perguntas.append(
                f"O pedido “{texto[:60]}…” depende de “{condicao}”, e esse dado não "
                f"está definido. Ele entra na peça ou não?")
            continue
        preenchido, falta = preencher(texto, dados)
        faltando |= falta
        itens.append(preenchido)

    for i, texto in enumerate(itens):
        letra = LETRAS[i] if i < len(LETRAS) else f"a{i}"
        final = "." if i == len(itens) - 1 else ";"
        r.peca.add(Paragrafo(f"{letra}) {texto}{final}", recuo=False))
    return faltando


PEDIDOS_ATRELADOS = {
    "tutela de urgência": "tutela",
    "exibição": "exibi",
    "prioridade de tramitação": "priorid",
    "gratuidade": "gratuid",
}


def _conferir_coerencia(r: Roteiro) -> None:
    """Pedido sem o capítulo que o sustenta é incoerência que salta aos olhos de quem
    lê a peça, e o gerador não pode produzi-la sozinho."""
    corpo = " ".join(b.texto for b in r.peca.blocos
                     if isinstance(b, Paragrafo)).lower()
    titulos = " ".join(b.texto for b in r.peca.blocos
                       if isinstance(b, Titulo)).lower()
    for rotulo, marca in PEDIDOS_ATRELADOS.items():
        if rotulo in corpo and marca not in titulos:
            r.revisoes.append(
                f"a peça pede {rotulo} mas não tem o capítulo correspondente — "
                f"conferir antes de protocolar")
