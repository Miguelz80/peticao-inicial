"""Calculador atuarial — monta a tabela de reajuste devido.

Fórmula confirmada contra planilha real do escritório (cadeia de 9 anos, 9 passos
exatos, ver docs/05-achados-caso-sulamerica.md):

    devido[n] = devido[n-1] × (1 + índice ANS do período do aniversário)
                            × (1 + faixa etária legítima, quando houver)

Duas regras que vêm de erro observado, não de preferência:

1. **Não arredondar entre os anos.** Precisão cheia por dentro, arredondamento só na
   exibição. Arredondando ano a ano a cadeia erra centavos que se acumulam ao longo
   de uma década.
2. **Ano sem índice bloqueia o caso.** Nunca pular o ano, nunca estimar. Índice errado
   contamina toda a cadeia e é invisível na revisão da peça.

O que este módulo NÃO faz: decidir se um reajuste por faixa etária é legítimo. Isso é
juízo jurídico (Temas 952 e 1016 do STJ) — ele identifica e devolve para decisão humana.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP


# --------------------------------------------------------------------------- #
# Índices ANS — espelham references/indices-ans.md
# --------------------------------------------------------------------------- #

# Chave = ano de início do período (maio/ANO a abril/ANO+1).
#
# A série NÃO mora aqui: mora em references/indices-ans.md, que a advogada edita sem
# abrir código. Este módulo só lê a tabela de lá. Duplicar os valores em .py criaria
# duas versões da verdade, e a de baixo é a que ninguém revisa.
TABELA_INDICES = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "references", "indices-ans.md")

# | maio/2022 – abril/2023 | **15,50%** |   → 2022: 0.1550
# Aceita o traço de menos tipográfico (−) além do hífen: a linha de 2021 usa o primeiro.
_LINHA_INDICE = re.compile(
    r"^\s*\|\s*maio/(\d{4})\s*[–\-]\s*abril/\d{4}\s*\|\s*\**\s*"
    r"([−\-]?\d+[.,]?\d*)\s*%", re.MULTILINE)


class TabelaIndisponivel(Exception):
    pass


def carregar_indices(caminho: str = "") -> dict[int, Decimal]:
    """Lê a série de índices de references/indices-ans.md.

    Arquivo ilegível ou tabela vazia é erro, nunca fallback silencioso para uma série
    embutida: calcular com índice que a advogada não vê é o defeito que este módulo
    inteiro existe para evitar.
    """
    caminho = caminho or TABELA_INDICES
    try:
        with open(caminho, encoding="utf-8") as f:
            texto = f.read()
    except OSError as erro:
        raise TabelaIndisponivel(
            f"não consegui ler a tabela de índices ANS em {caminho}: {erro}") from erro

    serie: dict[int, Decimal] = {}
    for ano, pct in _LINHA_INDICE.findall(texto):
        # percentual → fração. "15,50%" é 0,1550, não 15,50 — a confusão de unidade já
        # multiplicou uma mensalidade por onze com teste verde por cima.
        bruto = pct.replace("\u2212", "-").replace(",", ".")
        serie[int(ano)] = Decimal(bruto) / Decimal(100)

    if not serie:
        raise TabelaIndisponivel(
            f"{caminho} não tem nenhuma linha de índice no formato "
            f"“| maio/ANO – abril/ANO+1 | **N,NN%** |”. Corrija a tabela antes de "
            f"calcular — não há série embutida para cair de volta.")
    return serie


INDICES_ANS: dict[int, Decimal] = carregar_indices()

ANUAL, FAIXA_ETARIA, INDEFINIDO = "ANUAL", "FAIXA_ETARIA", ""
MESES_RESTITUICAO = 36          # Tema 610/STJ — prescrição trienal


def periodo_ans(ano: int, mes: int) -> int:
    """O período ANS vai de maio a abril. Aniversário em maio/dezembro usa o índice do
    próprio ano; em janeiro/abril, o do ano anterior."""
    return ano if mes >= 5 else ano - 1


def indice_do_aniversario(ano: int, mes: int) -> Decimal:
    p = periodo_ans(ano, mes)
    if p not in INDICES_ANS:
        raise IndiceAusente(p)
    return INDICES_ANS[p]


class IndiceAusente(Exception):
    def __init__(self, periodo: int):
        self.periodo = periodo
        super().__init__(
            f"Sem índice ANS para o período maio/{periodo}–abril/{periodo+1}. "
            f"Preencha references/indices-ans.md a partir da fonte oficial da ANS "
            f"antes de calcular — não estimar."
        )


# --------------------------------------------------------------------------- #
# Modelo
# --------------------------------------------------------------------------- #

def d(valor) -> Decimal:
    """Aceita '1.234,56', '1234.56', float ou Decimal."""
    if isinstance(valor, Decimal):
        return valor
    if isinstance(valor, (int, float)):
        return Decimal(str(valor))
    t = str(valor).strip().replace("R$", "").strip()
    if "," in t:
        t = t.replace(".", "").replace(",", ".")
    return Decimal(t or "0")


def q(valor: Decimal) -> Decimal:
    """Arredonda para exibição. Só aqui — nunca no meio da cadeia."""
    return valor.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _brl(v: Decimal) -> str:
    s = f"{q(v):,.2f}".replace(",", "·").replace(".", ",").replace("·", ".")
    return f"R$ {s}"


def _inicio_da_janela(reais: list["Competencia"], meses: int) -> tuple[int, int]:
    janela = reais[-meses:]
    return janela[0].chave if janela else reais[0].chave


def _pct(v: Decimal) -> str:
    return f"{v*100:.2f}%".replace(".", ",")


@dataclass
class Competencia:
    ano: int
    mes: int
    valor_pago: Decimal
    tipo_reajuste: str = INDEFINIDO      # ANUAL | FAIXA_ETARIA | "" (não declarado)

    @property
    def rotulo(self) -> str:
        nomes = ["", "janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho",
                 "agosto", "setembro", "outubro", "novembro", "dezembro"]
        return f"{nomes[self.mes]}/{self.ano}"

    @property
    def chave(self) -> tuple[int, int]:
        return (self.ano, self.mes)


@dataclass
class Linha:
    competencia: Competencia
    reajuste_aplicado: Decimal          # o que a operadora cobrou nesta competência
    reajuste_devido: Decimal            # o que se aplicou ao devido nesta competência
    valor_devido: Decimal               # precisão cheia
    diferenca: Decimal                  # precisão cheia


@dataclass
class Pendencia:
    """Reajuste fora do mês de aniversário, sem tipo declarado. Pode ser faixa etária
    legítima (entra no devido) ou aumento sem previsão (é o que se impugna)."""
    competencia: str
    percentual: Decimal
    pergunta: str


@dataclass
class Resultado:
    linhas: list[Linha] = field(default_factory=list)
    pendencias: list[Pendencia] = field(default_factory=list)
    bloqueios: list[str] = field(default_factory=list)
    avisos: list[str] = field(default_factory=list)
    mes_aniversario: int = 0
    janela_restituicao: tuple[str, str] | None = None

    # ---- resumo ----
    @property
    def valor_pago_atual(self) -> Decimal:
        return self.linhas[-1].competencia.valor_pago if self.linhas else Decimal(0)

    @property
    def valor_devido_atual(self) -> Decimal:
        return self.linhas[-1].valor_devido if self.linhas else Decimal(0)

    @property
    def diferenca_mensal(self) -> Decimal:
        return self.valor_pago_atual - self.valor_devido_atual

    @property
    def total_pago(self) -> Decimal:
        return sum((l.competencia.valor_pago for l in self.linhas), Decimal(0))

    @property
    def total_devido(self) -> Decimal:
        return sum((l.valor_devido for l in self.linhas), Decimal(0))

    @property
    def total_diferenca(self) -> Decimal:
        return sum((l.diferenca for l in self.linhas), Decimal(0))

    def restituicao(self, meses: int = MESES_RESTITUICAO,
                    ate: tuple[int, int] | None = None) -> Decimal:
        """Prescrição trienal (Tema 610/STJ).

        Dois parâmetros porque a resposta muda de valor conforme a convenção, e a
        convenção do escritório ainda não está fechada (pergunta A7):

        - `ate` é o marco final (ano, mês). Sem ele, a última competência da série.
          Numa planilha real do escritório o marco estava **dois meses atrás** da
          última competência — provavelmente congelado na data em que se calculou —
          e a peça saiu com a restituição desatualizada.
        - `meses` é o tamanho da janela. 36 é a leitura direta de "últimos 3 anos";
          contar do mesmo mês três anos antes **incluindo as duas pontas** dá 37
          competências, e é o que aquela planilha fazia. A diferença entre as duas
          convenções, no caso real, passou de mil reais no pedido.
        """
        janela = self._janela(meses, ate)
        if janela:
            self.janela_restituicao = (janela[0].competencia.rotulo,
                                       janela[-1].competencia.rotulo)
        return self._somar_positivas(janela)

    def _somar_positivas(self, linhas: list["Linha"]) -> Decimal:
        """Soma só as competências pagas **a maior**.

        Mês em que se pagou menos que o devido não gera crédito para a operadora nesta
        ação: cada pagamento indevido é uma pretensão própria. Deixar a diferença
        negativa abater as positivas reduziria o pedido sem base — e é o que acontecia
        antes. Quando há competência negativa, o cálculo avisa.
        """
        negativas = [l for l in linhas if l.diferenca < 0]
        if negativas and not any("pagas ABAIXO" in a for a in self.avisos):
            self.avisos.append(
                f"{len(negativas)} competência(s) da janela foram pagas ABAIXO do valor "
                f"devido pelos índices ANS (ex.: {negativas[0].competencia.rotulo}). "
                f"A restituição soma apenas as competências pagas a maior — conferir "
                f"com a advogada se é assim que o escritório trata o caso.")
        return sum((l.diferenca for l in linhas if l.diferenca > 0), Decimal(0))

    def restituicao_corrente(self) -> Decimal:
        """Soma da janela já definida, sem redefini-la. Quem precisa de outra janela
        chama `restituicao()` com os parâmetros."""
        if self.janela_restituicao is None:
            return self.restituicao()
        inicio, fim = self.janela_restituicao
        dentro, ativo = [], False
        for l in self.linhas:
            if l.competencia.rotulo == inicio:
                ativo = True
            if ativo:
                dentro.append(l)
            if l.competencia.rotulo == fim:
                break
        # Mesma regra de restituicao(): só as competências pagas a maior. Somando
        # também as negativas, este caminho — que é o que a Conferência usa como
        # referência — divergia do número escrito na peça e reprovava em C6 uma peça
        # correta, sempre que a série tinha alguma competência paga a menor.
        return self._somar_positivas(dentro)

    def _janela(self, meses: int, ate: tuple[int, int] | None) -> list["Linha"]:
        linhas = self.linhas
        if ate is not None:
            linhas = [l for l in linhas if l.competencia.chave <= ate]
        return linhas[-meses:]

    def conferir(self) -> list[str]:
        """Autoconferência dos totais. Existe porque a planilha real do escritório
        reprova aqui: pago − devido não fecha com o total da coluna diferença."""
        erros = []
        if q(self.total_pago - self.total_devido) != q(self.total_diferenca):
            erros.append(
                f"total pago − total devido = {q(self.total_pago - self.total_devido)} "
                f"≠ total da coluna diferença = {q(self.total_diferenca)}")
        # não recalcula a restituição: conferir() não pode sobrescrever a janela que
        # o chamador escolheu — era assim que o alerta de marco congelado se perdia.
        padrao = sum((l.diferenca for l in self._janela(MESES_RESTITUICAO, None)),
                     Decimal(0))
        if padrao > self.total_diferenca:
            erros.append("restituição de 3 anos maior que a diferença total da série")
        ultima = self.linhas[-1].competencia.rotulo if self.linhas else ""
        if self.janela_restituicao and self.janela_restituicao[1] != ultima:
            erros.append(
                f"a janela da restituição termina em {self.janela_restituicao[1]} mas a "
                f"série vai até {ultima} — marco congelado? (pergunta A7)")
        return erros

    @property
    def bloqueado(self) -> bool:
        return bool(self.bloqueios or self.pendencias)


# --------------------------------------------------------------------------- #
# Cálculo
# --------------------------------------------------------------------------- #

def calcular(competencias: list[Competencia], mes_aniversario: int,
             faixa_etaria_aceita: dict[tuple[int, int], Decimal] | None = None,
             ) -> Resultado:
    """Monta a tabela de reajuste devido.

    `faixa_etaria_aceita` traz as decisões humanas: chave (ano, mês), valor = percentual
    a incorporar ao devido. Competência ausente do dicionário e com reajuste fora do
    aniversário vira pendência — o cálculo não segue sozinho.
    """
    aceitas = faixa_etaria_aceita or {}
    res = Resultado(mes_aniversario=mes_aniversario)

    ordenadas = sorted(competencias, key=lambda c: (c.ano, c.mes))
    reais = [c for c in ordenadas if c.valor_pago > Decimal("0.01")]
    if not reais:
        res.bloqueios.append("nenhuma competência com valor real — nada a calcular")
        return res

    devido = reais[0].valor_pago          # base: primeira competência com valor real
    pago_anterior: Decimal | None = None
    # Início da janela de restituição: é dentro dela que um índice faltando realmente
    # compromete o pedido. Antes disso, dá para seguir truncando com aviso.
    inicio_da_janela = _inicio_da_janela(reais, MESES_RESTITUICAO)

    for c in reais:
        aplicado = Decimal(0)
        if pago_anterior and pago_anterior > 0:
            aplicado = (c.valor_pago / pago_anterior) - 1

        devido_pct = Decimal(0)
        primeira = c is reais[0]
        aniversario = (c.mes == mes_aniversario) and not primeira

        if aniversario:
            try:
                devido_pct = indice_do_aniversario(c.ano, c.mes)
                devido = devido * (1 + devido_pct)
                # O índice ANS é teto autorizado, não reajuste obrigatório. Quando a
                # operadora aplicou MENOS que o teto, a cadeia do devido passa acima
                # da mensalidade efetivamente paga e aquelas competências saem da
                # restituição. Isso só reduz o pedido, nunca o infla — mas muda o
                # valor, então nomeia a causa em vez de deixar o sintoma solto.
                if aplicado < devido_pct - Decimal("0.0005"):
                    res.avisos.append(
                        f"em {c.rotulo} a operadora aplicou {_pct(aplicado)}, abaixo do "
                        f"índice ANS de {_pct(devido_pct)} usado na cadeia do valor "
                        f"devido. A partir daí o devido fica acima do que se pagou e "
                        f"essas competências não entram na restituição — decisão da "
                        f"advogada se a cadeia deve seguir o teto ANS ou o percentual "
                        f"efetivamente aplicado (pergunta A10).")
            except IndiceAusente as erro:
                # Ano sem índice não estima e não trava o caso inteiro: se o
                # aniversário é anterior à janela de restituição, a cadeia recomeça
                # da mensalidade efetivamente paga ali. Isso só pode REDUZIR a
                # restituição — aceita como legítimo o que se pagou até aquele ponto —,
                # nunca inflá-la. Dentro da janela, aí sim bloqueia.
                if c.chave >= inicio_da_janela:
                    res.bloqueios.append(str(erro))
                    return res
                devido = c.valor_pago
                devido_pct = Decimal(0)
                res.avisos.append(
                    f"sem índice ANS para o período maio/{erro.periodo}–abril/"
                    f"{erro.periodo+1}: a cadeia do valor devido recomeça em "
                    f"{c.rotulo}, a partir da mensalidade paga. Isso reduz a "
                    f"restituição — preencha o índice em references/indices-ans.md "
                    f"e recalcule para obter o valor cheio.")

        elif not primeira and aplicado > Decimal("0.005"):
            # Reajuste fora do aniversário: faixa etária legítima entra no devido,
            # aumento sem previsão não entra — e essa distinção é jurídica.
            if c.chave in aceitas:
                extra = aceitas[c.chave]
                devido = devido * (1 + extra)
                devido_pct = extra
                if c.tipo_reajuste == INDEFINIDO:
                    c.tipo_reajuste = FAIXA_ETARIA
            else:
                # A planilha declarar "faixa etária" não decide nada: a legitimidade
                # é juízo (Temas 952 e 1016). Antes, competência já rotulada passava
                # direto e era impugnada por inteiro sem ninguém ser consultado.
                declarada = c.tipo_reajuste == FAIXA_ETARIA
                res.pendencias.append(Pendencia(
                    competencia=c.rotulo,
                    percentual=aplicado,
                    pergunta=(
                        f"Em {c.rotulo} a mensalidade subiu {_pct(aplicado)} fora do "
                        f"mês de aniversário"
                        + (", e a planilha marca como faixa etária. " if declarada
                           else ". ")
                        + f"Esse reajuste tem previsão contratual — e portanto entra "
                          f"no valor devido — ou fica de fora, por ser o que se "
                          f"impugna?"),
                ))

        res.linhas.append(Linha(
            competencia=c,
            reajuste_aplicado=aplicado,
            reajuste_devido=devido_pct,
            valor_devido=devido,
            diferenca=c.valor_pago - devido,
        ))
        pago_anterior = c.valor_pago

    return res


# --------------------------------------------------------------------------- #
# Saída
# --------------------------------------------------------------------------- #

CABECALHOS = ["Mês/Ano", "Valor Pago", "Reajuste Aplicado", "Tipo de Reajuste",
              "Reajuste Devido", "Valor Devido", "Diferença"]


def tabela(res: Resultado) -> list[list[str]]:
    """Linhas prontas para virar `w:tbl` no gerador — nunca imagem."""
    linhas = [CABECALHOS]
    for l in res.linhas:
        tipo = l.competencia.tipo_reajuste
        # Só é "Anual" no mês de aniversário. Reajuste aceito fora dele é faixa
        # etária, e rotulá-lo de anual na tabela que vai à peça seria afirmar
        # em juízo algo diferente do que se decidiu.
        if not tipo and l.reajuste_devido != 0:
            tipo = ANUAL if l.competencia.mes == res.mes_aniversario else FAIXA_ETARIA
        linhas.append([
            l.competencia.rotulo,
            _brl(l.competencia.valor_pago),
            _pct(l.reajuste_aplicado),
            "Anual" if tipo == ANUAL else ("Faixa etária" if tipo == FAIXA_ETARIA else ""),
            _pct(l.reajuste_devido),
            _brl(l.valor_devido),
            _brl(l.diferenca),
        ])
    linhas.append(["Total", _brl(res.total_pago), "", "", "",
                   _brl(res.total_devido), _brl(res.total_diferenca)])
    return linhas


def resumo(res: Resultado) -> dict[str, str]:
    restituicao = res.restituicao()
    janela = res.janela_restituicao
    return {
        "Valor Pago (Atual)": _brl(res.valor_pago_atual),
        "Valor Devido": _brl(res.valor_devido_atual),
        "Diferença (Mensal)": _brl(res.diferenca_mensal),
        "Restituição (últimos 3 anos)": _brl(restituicao),
        "Janela da restituição": f"{janela[0]} a {janela[1]}" if janela else "—",
    }
